from django.contrib import admin
from faculty.models import Facultydetails, Studentdetails, Courseinfo

admin.site.register(Facultydetails)
admin.site.register(Studentdetails)
admin.site.register(Courseinfo)

# Register your models here.
